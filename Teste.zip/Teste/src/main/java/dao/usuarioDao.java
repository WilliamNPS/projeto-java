
package dao;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexao.ConexaoPGSQL;
import dto.usuarioDto;

public class usuarioDao {
	
	public void save(Object o) throws java.lang.ClassNotFoundException{

		usuarioDto usrDto = (usuarioDto)o;
		String consulta = "INSERT INTO usuario (usr_login, usr_senha) " +
		" VALUES ('"+ usrDto.getUsr_login() +
		"','"+usrDto.getUsr_senha()+"');";
		System.out.println(consulta);

		try {
			ConexaoPGSQL conexao = new ConexaoPGSQL();
			Statement stmt = conexao.Conectar();
			usuarioDto usrDto02 = new usuarioDto();
			usrDto02 = getUsuario(usrDto.getUsr_login().trim(),usrDto.getUsr_senha().trim());
			if (usrDto02 == null)
			{
				try {
					stmt.executeUpdate(consulta);
				} catch (SQLException e) {
					System.err.print("SQL exception: ");
					System.err.println(e.getMessage());
				}
			}
			conexao.Desconectar();

		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public usuarioDto getUsuario(String login, String senha) {
		
		usuarioDto usrDto = new usuarioDto();
		
		String consulta = "SELECT usr_codigo,usr_login,usr_senha FROM " + "usuario " +
		"WHERE usr_login='" + login +"' " +
		"AND usr_senha='"+ senha + "'";
		
		System.out.println(consulta);
		
		try {
			ConexaoPGSQL conexao = new ConexaoPGSQL();
			Statement stmt = conexao.Conectar();
			//System.out.println("TESTE");
			ResultSet resultSet = null;
			resultSet = stmt.executeQuery(consulta);
			
			if(resultSet.next()){
				usrDto.setUsr_codigo(resultSet.getInt("usr_codigo"));
				usrDto.setUsr_login(resultSet.getString("usr_login"));
				usrDto.setUsr_senha(resultSet.getString("usr_senha"));
			}else usrDto = null;
			
			conexao.Desconectar();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return usrDto;
	}

}

