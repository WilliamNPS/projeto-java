package dao;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import conexao.ConexaoPGSQL;
import dto.contatoDto;

public class contatoDao {

	public contatoDao() {
		// TODO Auto-generated constructor stub
	}

	public Collection list_contatos() throws Exception
	{
		Collection<contatoDto> collection = new ArrayList<contatoDto>();
		ResultSet resultSet;
		String consulta = "select * from contato as c";
		consulta = consulta + " order by c.cont_nome";
		try {
			ConexaoPGSQL conexao = new ConexaoPGSQL();
			Statement stmt = conexao.Conectar();
			contatoDto contato;
			resultSet = stmt.executeQuery(consulta);
			while (resultSet.next()){
				contato = new contatoDto();
				contato.setCont_codigo(Integer.valueOf(resultSet.getInt("cont_codigo")));
				contato.setCont_nome(resultSet.getString("cont_nome"));
				contato.setCont_email(resultSet.getString("cont_email"));
				contato.setCont_fone(resultSet.getString("cont_fone"));
				collection.add(contato);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return collection;
	}
}