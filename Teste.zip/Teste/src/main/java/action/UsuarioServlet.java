package action;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import dao.usuarioDao;
import dto.usuarioDto;
/**
* Servlet implementation class LogonServlet
*/
public class UsuarioServlet extends HttpServlet{
private static final long serialVersionUID = 2560707713814271218L;

public UsuarioServlet() {
	super();
	//contexto=getServletContext();
	// TODO Auto-generated constructor stub
}
protected void doGet(HttpServletRequest request,
HttpServletResponse response) throws ServletException, IOException {
	try{
		executar(request, response);
	}catch (Exception e) {
		// TODO: handle exception
	}
}
protected void doPost(HttpServletRequest request,
HttpServletResponse response) throws ServletException, IOException {
	try{
		executar(request, response);
	}catch (Exception e) {
		// TODO: handle exception
	}
}
protected void executar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, Exception {
	try{
		cadastro(request, response);
	}catch (Exception e) {
		// TODO: handle exception
	}
}
public void cadastro(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException, Exception {
	String login = request.getParameter("nome");
	String senha = request.getParameter("senha");
	usuarioDao usuarioDao = new usuarioDao();
	usuarioDto usuario = new usuarioDto();
	usuario.setUsr_login(login);
	usuario.setUsr_senha(senha);
	try
	{
		usuarioDao.save(usuario);
	}catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	PrintWriter out = response.getWriter();
	out.println("<script>parent.location.href='" + request.getContextPath() + "/index.jsp'</script>");
	out.flush();
	out.close();
	}
}

