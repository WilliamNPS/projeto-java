package dto;
public class contatoDto {

	private Integer cont_codigo;
	private String cont_nome;
	private String cont_email;
	private String cont_fone;

	public Integer getCont_codigo() {
		return cont_codigo;
	}
	public void setCont_codigo(Integer cont_codigo) {
		this.cont_codigo = cont_codigo;
	}

	public String getCont_nome() {
		return cont_nome;
	}
	public void setCont_nome(String cont_nome) {
		this.cont_nome = cont_nome;
	}

	public String getCont_email() {
		return cont_email;
	}
	public void setCont_email(String cont_email) {
		this.cont_email = cont_email;
	}

	public String getCont_fone() {
		return cont_fone;
	}
	public void setCont_fone(String cont_fone) {
		this.cont_fone = cont_fone;
	}
}